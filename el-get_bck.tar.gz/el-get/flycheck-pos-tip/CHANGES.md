# Changelog #

## master (in development) ##

- Add space between tooltip and bottom of line
- Don’t try to hide GUI tooltips on non-GUI displays [GH-18]

## 0.2 (Jan 15, 2016) ##

- Add `flycheck-pos-tip-timeout` [GH-9]
- Fall back to echo area display of errors on TTY frames [GH-11] [GH-14]
- Remove `flycheck-pos-tip-show-function`
- Add `flycheck-pos-tip-display-errors-tty-function`

## 0.1 (Nov 16, 2015) ##

- Initial release
