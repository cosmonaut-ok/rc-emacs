return (
  <ModalTrigger modal={<InviteForm auth={this.props.auth} />} />
);

return (
  <li>
    <ModalTrigger modal={ <InviteForm auth={this.props.auth} /> }>
      <a href="#">Invite Representative</a>
    </ModalTrigger>
  </li>
);

return (
  <div>
    <div>xs</div>
    <OtherComponent/>
    <OtherComponent class="toto"
                    {...props}
                    id="fr" />
  </div>;
);
