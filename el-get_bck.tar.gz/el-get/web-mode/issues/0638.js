if (x &&
    y) {
      return 1;
}
