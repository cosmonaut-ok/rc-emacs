function test() {
  switch (q) {
    case 'a':
      return a;
    case 'b':
      return b;
    case 'c':
      return c;
    case 'd':
      return d;
    default:
      return [];
  }
}
