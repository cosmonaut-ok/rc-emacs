<?php

class Foo {
  /* public function bar() {
     } */
}

?>
