foo() {
  // cdcd
  bar()
  baz()
  if(true)
    hello();
  if (true) //csdc
    hello();

}

if ( value.length < fieldSpec.minNumberOfChar ||
     value.length > fieldSpec.maxNumberOfChar ||
     value.match( fieldSpec.pattern) )
  return true;
