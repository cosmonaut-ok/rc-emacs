= ido-better-flex

Just another fuzzy matching algorithm for use with emacs ido mode.

== Installation

Place the file on your load-path or if you have package.el installed:

    M-x package-install ido-better-flex

Then just enable it using:

    (ido-better-flex/enable)


