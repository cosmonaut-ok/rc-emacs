Hello,

Please, provide the following information and remove the useless parts.
Thanks in advance.

## bug?

### M-x markdown-toc-bug-report

Report back the output from that command here.
(You can quote it with ``` for a better readability).

### Expected behavior

What command did you use and what were you expecting?

### Actual behavior

What really happened?

### Steps to reproduce the behavior

How can we try and reproduce?

## Improvments?

### What do you want?

### Why is it better?

Thanks for sharing!

Cheers,
