/** An unused variable, and some invalid spacing */

(function() {
    var foo = ["Hello world" ];
}());
