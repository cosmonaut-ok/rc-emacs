#!/bin/sh

cat <(echo blah)
