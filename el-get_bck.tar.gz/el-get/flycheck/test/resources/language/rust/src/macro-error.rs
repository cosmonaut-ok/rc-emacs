fn foo() {
  println!("{}");
}
