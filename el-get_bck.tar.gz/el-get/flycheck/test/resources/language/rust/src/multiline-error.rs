fn foo(bar: u8) -> u8 {
    bar + 1
}

fn spam() {
    let i: i8 = -1;
    foo(i);
}
