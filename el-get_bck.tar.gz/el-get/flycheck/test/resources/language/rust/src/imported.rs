pub static BAR: u32 = 42;
