-- A syntax error caused by a missing quote
--
-- Checkers: lua

print "oh no

print "hello world"
