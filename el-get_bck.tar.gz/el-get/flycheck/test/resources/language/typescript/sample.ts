function invalidAlignment() {
  let a:string = "test string";
  alert('Hi!')
}