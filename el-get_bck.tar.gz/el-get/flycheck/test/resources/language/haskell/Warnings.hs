module Haskell.Warnings
where

spam eggs = map lines eggs

main :: IO ()
main = (putStrLn "hello world")
