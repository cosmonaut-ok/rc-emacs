# Thank you for your contribution!

Thank you for taking the time to submit your changes to Flycheck and help us
making Flycheck better step by step! :+1: :clap:

After you submitted your pull request we will soon review this pull request.  If
you think that we might have missed your pull request please ping us at
`@flycheck/maintainers`.

Meanwhile please take a look at the [Travis CI][] build status of your pull
request which you can see right above the comment input field.  If the build
failed please take a look to see if there were any formatting issues or test
failures.

You may now delete all this text and add a description of your changes.

Thank you for contributing to Flycheck!
