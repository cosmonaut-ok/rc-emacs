# El-Get Logo

So I saw that pangolin animal photos and wanted that to become the El-Get
logo. Enjoy!

I found http://openclipart.org/people/Jmlevick/Pangolin.svg which licence
hopefully allows me to use the work, and converted to ico and png. The
`mono` file is an attempt at desaturating the colors and getting all
black&white in case you need that, please consider contributing a better
version though.

 ![Color El-Get logo](https://raw.github.com/dimitri/el-get/master/logo/el-get.png)
 ![Monochrome El-Get logo](https://raw.github.com/dimitri/el-get/master/logo/el-get.mono.png)

