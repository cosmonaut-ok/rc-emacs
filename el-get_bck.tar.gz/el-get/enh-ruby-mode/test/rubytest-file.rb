def foo
  simple.meth

  %_bosexp#{sdffd} test1_[1..4].si
end

def backward_sexp
  %_string #{expr %_another_} word_
  sdfdfsdfs
end
